pref("browser.startup.homepage",        "chrome://cck-Wesleyan/content/cck.properties");
pref("startup.homepage_override_url",   "");
pref("startup.homepage_welcome_url",   "");
pref("browser.shell.checkDefaultBrowser", false);
pref("browser.rights.3.shown", true);
pref("browser.rights.override", true);
