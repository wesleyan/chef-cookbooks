const Cc = Components.classes;
const Ci = Components.interfaces;

Components.utils.import("resource://gre/modules/XPCOMUtils.jsm");

function WesleyanCCKService() {}

WesleyanCCKService.prototype = {
  observe: function(aSubject, aTopic, aData) {
    switch(aTopic) {
      case "profile-after-change":
        Components.utils.import("resource://cck-Wesleyan/cckModule.jsm");
        break;
    }
  },
  classDescription: "CCK Service - Wesleyan",
  contractID: "@mozilla.org/cck-service-Wesleyan;2",
  classID: Components.ID("{9aa7e124-c7a9-8d41-90c8-22874959d86d}"),
  QueryInterface: XPCOMUtils.generateQI([Ci.nsIObserver]),
  _xpcom_categories: [{category: "profile-after-change"}]
}

if (XPCOMUtils.generateNSGetFactory)
  var NSGetFactory = XPCOMUtils.generateNSGetFactory([WesleyanCCKService]);
else
  var NSGetModule = XPCOMUtils.generateNSGetModule([WesleyanCCKService]);

